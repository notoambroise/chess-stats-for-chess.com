# Chess Stats Dashboard — 5.3.0

## Installation / mise à jour
1. Décompresser le ZIP.
2. Ouvrir `chrome://extensions` et activer le mode développeur.
3. Désactiver l’ancienne copie pour éviter deux tableaux simultanés.
4. « Charger l’extension non empaquetée » puis sélectionner `chess-stats-dashboard`.
5. Ouvrir ou recharger une page Stats : `/member/pseudo/stats` ou `/stats/overview/pseudo` sur www.chess.com. Lors d’une navigation interne depuis une autre page, recharger la page Stats si nécessaire.

## Changements
- Activité par heure et jour : échelle verticale automatique, graduations et barres SVG, sans dépassement lié aux grandes valeurs.
- Temps moyen par coup jusqu’au coup 100, axes et graduations numériques.
- Roue unique subdivisée par motif de victoire, défaite et nulle ; détails au survol et au clavier.
- Écart de précision signé en points de pourcentage, sur le même échantillon de parties.
- Thème Chess.com (vert et gris foncé).
- Précision moyenne du joueur et des adversaires issue du champ `accuracies` publié par Chess.com. Comparaison sur les mêmes parties, avec effectif et couverture. Une précision manquante n’est jamais remplacée par zéro.
- Courbes Elo Canvas séparées par cadence, temps en abscisse et Elo en ordonnée. Toutes les parties classées sont tracées, avec un petit point par partie. Recherche du point au survol par dichotomie, clavier, redimensionnement et affichage haute densité.
- Horloges séparées pour chaque couleur ; seul le temps du joueur est retenu, avec incrément. Moyenne pondérée par nombre de mesures.
- Cache mensuel et cache global de 15 minutes ; actualisation complète manuelle. Requêtes séquentielles, délais réseau et reprises sur erreurs temporaires. Signalement des mois manquants et du cache plein.
- Requêtes API exécutées dans un service worker avec liste stricte d’endpoints publics autorisés.
- Correction du double comptage des résultats inconnus, exclusion des variantes et des parties étrangères au profil.
- Série de victoires courante et record, calendrier comprenant les jours sans activité, filtre de dates accessible sans modification lors de l’annulation, thème automatique et export CSV de la sélection.
- Durée estimée depuis les dates archivées ; parties différées exclues. Retrait du plafond arbitraire de quatre heures.

## Interprétation des données
La précision apparaît seulement si Chess.com la publie déjà pour les deux joueurs. Cette extension ne lance pas d’analyse moteur et ne débloque pas Game Review. La moyenne des parties analysées peut être biaisée ; le taux de couverture est affiché.

Le classement archivé est celui attaché à la partie, pas une reconstruction exacte de chaque variation Elo. Les résultats par longueur ne constituent pas une évaluation positionnelle des phases. Les statistiques d’horloge dépendent des annotations PGN et des contrôles simples avec incrément ; les cadences différées ou complexes sont exclues. La durée écoulée inclut les éventuelles pauses. Les heures et jours utilisent le fuseau du navigateur.

Le premier import d’un profil très actif peut prendre du temps. Le cache est local et soumis au quota Chrome. Aucune donnée n’est envoyée à un service tiers ; seule l’API publique de Chess.com est interrogée. Les données exportées restent sur l’ordinateur.

## Vérification
`node --test tests/*.test.cjs`

Tests automatisés des calculs et du service worker, validation syntaxique et JSON. La compatibilité visuelle avec le DOM Chess.com connecté doit être vérifiée dans Chrome : elle n’a pas été testée dans une session utilisateur réelle.

## Fiabilité du classement (v5.3)
L’Elo estimé a été retiré, y compris du modèle. Le dernier Elo archivé reste affiché comme donnée factuelle. Le score /100 intègre désormais la cohérence du taux de victoire avec les Elo adverses et l’écart absolu de précision, à influence bornée. Tous les détails de calcul figurent dans FORMULE.md et dans « Formule et limites » du tableau. Ce modèle est heuristique et non calibré, pas une probabilité de justesse, une mesure de talent ou un détecteur de triche.

Logo original (pion et histogramme), icônes Chrome et source vectorielle inclus. Paramètres : dix thèmes, accent personnalisé, densité, taille du texte, animations, visibilité des sections et réinitialisation.

Validation v5.3 : 25 tests automatisés et contrôle syntaxique. Compatibilité visuelle finale à vérifier dans Chrome sur Chess.com.
