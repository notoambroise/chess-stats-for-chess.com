"use strict";
// Only the documented, read-only player endpoints may be requested.
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(message?.type!=="chess-api")return;
 if(sender.id!==chrome.runtime.id){reply({ok:false,error:"Origine refusée"});return;}
 let url;try{url=new URL(message.url);}catch{reply({ok:false,error:"URL invalide"});return;}
 if(url.origin!=="https://api.chess.com"||url.search||url.hash||!/^\/pub\/player\/[a-zA-Z0-9_-]+(?:\/stats|\/games\/archives|\/games\/\d{4}\/\d{2})?$/.test(url.pathname)){
 reply({ok:false,error:"Endpoint non autorisé"});return;
 }
 (async()=>{
 for(let attempt=0;attempt<3;attempt++){
 try{
 const r=await fetch(url.href,{headers:{Accept:"application/json"},signal:AbortSignal.timeout(20000),credentials:"omit"});
 if((r.status===429||r.status>=500)&&attempt<2){await new Promise(resolve=>setTimeout(resolve,1000*2**attempt));continue;}
 if(!r.ok)throw Error(r.status===404?"Profil ou archives introuvables":`API Chess.com : ${r.status}`);
 reply({ok:true,data:await r.json()});return;
 }catch(e){if(attempt===2){reply({ok:false,error:e.name==="TimeoutError"?"Délai de connexion dépassé":e.message});return;}}
 }
 })();return true;
});
