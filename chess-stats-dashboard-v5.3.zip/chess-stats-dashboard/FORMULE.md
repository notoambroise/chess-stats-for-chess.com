# Fiabilité Elo /100 — formule v2 (extension 5.3)

Score heuristique de solidité du classement, non calibré statistiquement. Aucun Elo estimé. Calcul indépendant par cadence.

## Échantillon
Parties classées standard dans les filtres actifs, datées de moins de 180 jours, limitées aux 400 dernières. Résultat connu et classements présents pour les deux joueurs.

Pour chaque partie i, âge a_i en jours et poids w_i = exp(-a_i/60).
M = somme(w_i) ; n_eff = M²/somme(w_i²).
Les taux W (victoires) et N (nulles) sont pondérés par w_i et divisés par M.

## Socle B
B = V^0,30 × A^0,15 × D^0,15 × F^0,15 × I^0,15 × S^0,10

- V = 1 - exp(-M/50) : volume pondéré.
- A = min(1, jours actifs UTC/20).
- D = min(1, adversaires effectifs/25). Pour chaque adversaire j, m_j = somme des poids des parties contre j ; adversaires effectifs = M²/somme(m_j²).
- F = exp(-âge de la dernière partie/60).
- S = 1/(1+(sigma_Elo/150)²), sigma_Elo étant l’écart-type pondéré des classements du joueur archivés dans ces parties.
- E_i = 1/(1+10^((Elo_adverse_i-Elo_joueur_i)/400)).
- Q = (ln(10)/400)² × somme(w_i × E_i × (1-E_i)).
- I = 1/(1+(1/(100×sqrt(Q)))²) : information apportée par les résultats selon le modèle Elo simplifié.

## Modificateur résultats R
E = somme(w_i E_i)/M.
x = max(0, abs(W+N/2-E) - 1/sqrt(n_eff)).
R = 0,75 + 0,25 × exp(-x/0,15).

La winrate intervient explicitement : W+N/2 est le taux de points obtenus. On le compare au taux attendu contre les adversaires rencontrés, pas arbitrairement à 50 %. La tolérance 1/sqrt(n_eff) évite de surinterpréter les petites séries ; c’est une marge heuristique, pas un test statistique calibré. Les résultats peuvent réduire le socle de 25 % au maximum.

## Modificateur précision P
Sous-échantillon : les deux précisions sont des nombres valides de 0 à 100 et abs(Elo_joueur_i-Elo_adverse_i) ≤ 150.
d = somme(w_i × abs(precision_joueur_i-precision_adverse_i))/somme(w_i), calculé uniquement sur ce sous-échantillon.
c = somme des poids du sous-échantillon / M.
n_p = (somme des poids du sous-échantillon)²/somme des carrés de ces poids.
rho = c × min(1,n_p/20).
P = 1 - 0,10 × rho × d²/(d²+20²).
Sans données comparables : P = 1, d indisponible, couverture = 0.

Il s’agit de la moyenne des différences absolues par partie, pas de la différence absolue entre deux moyennes : les écarts de signes opposés ne s’annulent pas. L’écart est exprimé en points de pourcentage. Influence maximale : réduction de 10 %, atténuée si les données couvrent peu de parties.

## Score final
Fiabilité = arrondi(100 × B × R × P). Sans partie exploitable, aucun score n’est affiché.

## Limites
Poids, seuils et plafonds sont des choix explicites non validés sur une population. Une forte winrate peut refléter une progression ; un gros écart de précision peut venir du style, de positions faciles ou d’erreurs adverses. Les parties analysées sont sélectionnées et potentiellement biaisées. Une progression rapide réduit S. Ce score ne doit pas servir à qualifier l’intégrité du joueur. La précision reste un signal secondaire, sans lien universel démontré avec l’incertitude d’un classement.

Référence conceptuelle sur la distinction entre classement et incertitude : Mark Glickman, https://www.glicko.net/glicko/glicko.pdf . Le modèle de cette extension ne reproduit pas Glicko.
