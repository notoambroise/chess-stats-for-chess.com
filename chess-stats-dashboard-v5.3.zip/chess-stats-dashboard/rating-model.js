/* Reliability heuristic v2. Not a calibrated probability or a rating estimate. */
(function(root){
'use strict';
const expected=(r,o)=>1/(1+10**((o-r)/400));
function reliability(input,now=Date.now()){
 const games=input.filter(g=>Number.isFinite(g.r)&&Number.isFinite(g.o)&&Number.isFinite(g.t)&&g.t<=now&&g.t>=now-180*864e5&&[0,.5,1].includes(g.s)).sort((a,b)=>a.t-b.t).slice(-400);
 if(!games.length)return null;
 const opponents=new Map(),days=new Set();let sum=0,sum2=0;
 const data=games.map(g=>{const w=Math.exp(-(now-g.t)/(60*864e5));sum+=w;sum2+=w*w;opponents.set(g.op,(opponents.get(g.op)||0)+w);days.add(new Date(g.t).toISOString().slice(0,10));return {...g,w};});
 const nEff=sum*sum/sum2,diversity=sum*sum/[...opponents.values()].reduce((a,v)=>a+v*v,0),age=(now-games.at(-1).t)/864e5;
 const q=Math.log(10)/400;
 const information=data.reduce((n,g)=>{const e=expected(g.r,g.o);return n+g.w*e*(1-e)*q*q;},0),se=information>0?1/Math.sqrt(information):1000;
 const mean=data.reduce((n,g)=>n+g.w*g.r,0)/sum,spread=Math.sqrt(data.reduce((n,g)=>n+g.w*(g.r-mean)**2,0)/sum);
 const factors={volume:1-Math.exp(-sum/50),activity:Math.min(1,days.size/20),diversity:Math.min(1,diversity/25),freshness:Math.exp(-age/60),information:1/(1+(se/100)**2),stability:1/(1+(spread/150)**2)};
 const weights={volume:.30,activity:.15,diversity:.15,freshness:.15,information:.15,stability:.10};
 const base=Object.entries(weights).reduce((v,[k,w])=>v*Math.max(1e-8,factors[k])**w,1);
 const winrate=data.reduce((n,g)=>n+g.w*(g.s===1),0)/sum,drawrate=data.reduce((n,g)=>n+g.w*(g.s===.5),0)/sum;
 const expectedScore=data.reduce((n,g)=>n+g.w*expected(g.r,g.o),0)/sum;
 // Wins + half draws compared with expected Elo score, with sampling tolerance.
 const excess=Math.max(0,Math.abs(winrate+.5*drawrate-expectedScore)-1/Math.sqrt(nEff));
 const resultFactor=.75+.25*Math.exp(-excess/.15);
 const valid=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=100;
 const paired=data.filter(g=>Math.abs(g.r-g.o)<=150&&valid(g.ac)&&valid(g.oc));
 const pw=paired.reduce((n,g)=>n+g.w,0),pw2=paired.reduce((n,g)=>n+g.w*g.w,0),pn=pw2?pw*pw/pw2:0;
 const gap=pw?paired.reduce((n,g)=>n+g.w*Math.abs(g.ac-g.oc),0)/pw:null;
 const coverage=pw/sum,rho=coverage*Math.min(1,pn/20);
 const precisionFactor=gap===null?1:1-.10*rho*gap*gap/(gap*gap+400);
 return {score:Math.round(100*base*resultFactor*precisionFactor),current:games.at(-1).r,n:games.length,nEff,days:days.size,opponents:opponents.size,age:Math.round(age),factors,resultFactor,precisionFactor,winrate,drawrate,expectedScore,excess,gap,coverage,precisionN:paired.length,precisionEffective:pn};
}
root.ChessRatingModel={reliability,expected};if(typeof module!=='undefined')module.exports=root.ChessRatingModel;
})(globalThis);
