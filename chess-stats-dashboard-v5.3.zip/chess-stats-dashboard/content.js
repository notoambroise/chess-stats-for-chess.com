(() => {
"use strict";
if (window.__chessStatsDashboardV4) return;
window.__chessStatsDashboardV4 = true;
const $ = (s, r=document) => r.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const username = decodeURIComponent((location.pathname.match(/\/member\/([^/]+)\/stats/) || location.pathname.match(/\/stats\/(?:overview|live|daily|bullet|blitz|rapid)\/([^/]+)/))?.[1] || "");
if (!username) return;

const fmt=n=>new Intl.NumberFormat(undefined,{maximumFractionDigits:1}).format(n);
const dateISO=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const fromISO=s=>{const [y,m,d]=s.split("-").map(Number);return new Date(y,m-1,d,0,0,0,0)};
const today=new Date(); today.setHours(23,59,59,999);
let allGames=[], publicStats={}, publicProfile={}, prefs={accent:"",density:"comfortable",fontSize:100,animations:true,hiddenCards:[],theme:"dark",range:"all",start:"2007-01-01",end:dateISO(today),mode:"all"};


let loading=false, loadWarning="";
async function api(url){
 const response=await chrome.runtime.sendMessage({type:"chess-api",url});
 if(!response?.ok)throw Error(response?.error||"Connexion à l’API impossible");return response.data;
}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function loadData(force=false){
 if(loading)return;loading=true;loadWarning="";
 try{
 const key="chessdash_v5_"+username.toLowerCase();
 const cache=(await chrome.storage.local.get(key))[key];
 if(!force&&cache&&Date.now()-cache.time<15*60e3){allGames=cache.games;publicStats=cache.stats;publicProfile=cache.profile||{};return;}
 const base=`https://api.chess.com/pub/player/${encodeURIComponent(username.toLowerCase())}`;
 publicStats=await api(base+"/stats");const ar=await api(base+"/games/archives");
 publicProfile=await api(base).catch(()=>({}));
 const months=ar.archives||[],games=[];let failed=0;
 for(let i=0;i<months.length;i++){
 const mk="chessdash_month_"+months[i],saved=(await chrome.storage.local.get(mk))[mk];
 const current=months[i].endsWith(`/${new Date().getUTCFullYear()}/${String(new Date().getUTCMonth()+1).padStart(2,"0")}`);
 try{
 const month=(!force&&saved&&!current)?saved:await api(months[i]);
 games.push(...(month.games||[]));
 if(month!==saved)await chrome.storage.local.set({[mk]:month}).catch(()=>{});
 }catch(e){failed++;if(saved)games.push(...(saved.games||[]));}
 const status=$("#dash-status");if(status)status.textContent=`Importation : ${i+1}/${months.length} mois`;
 await wait(0);
 }
 if(failed===months.length&&months.length)throw Error("Archives inaccessibles. Réessaie dans quelques instants.");
 allGames=[...new Map(games.map(g=>[g.uuid||g.url||JSON.stringify(g),g])).values()];
 if(failed)loadWarning=`${failed} mois non actualisés : les statistiques peuvent être incomplètes.`;
 if(!failed)await chrome.storage.local.set({[key]:{time:Date.now(),games:allGames,stats:publicStats,profile:publicProfile}}).catch(()=>{loadWarning="Cache plein : données chargées, mais non conservées.";});
 }finally{loading=false;}
}
const headerCache=new Map();
function headers(pgn){if(headerCache.has(pgn))return headerCache.get(pgn);const o={};for(const m of (pgn||"").matchAll(/^\[(\w+)\s+"(.*?)"\]$/gm))o[m[1]]=m[2];if(headerCache.size>25000)headerCache.clear();headerCache.set(pgn,o);return o;}
function outcome(g){
 const h=headers(g.pgn), side=mySide(g), mine=g[side]?.result||"", theirs=g[side==="white"?"black":"white"]?.result||"";
 const draws=["agreed","repetition","stalemate","insufficient","50move","timevsinsufficient"];
 if(mine==="win")return "win";
 if(theirs==="win")return "loss";
 if(draws.includes(mine)||draws.includes(theirs)||h.Result==="1/2-1/2")return "draw";
 if(h.Result==="1-0")return side==="white"?"win":"loss";
 if(h.Result==="0-1")return side==="black"?"win":"loss";
 if(!h.Result||h.Result==="*")return "unknown";
 return "unknown";
}
function mySide(g){return (g.white?.username||"").toLowerCase()===username.toLowerCase()?"white":"black";}
function myRating(g){return g[mySide(g)]?.rating||null;}
function oppRating(g){return g[mySide(g)==="white"?"black":"white"]?.rating||null;}
function modeOf(g){return (g.time_class||"other").toLowerCase();}
function openingOf(g){const h=headers(g.pgn);return {name:h.Opening||h.ECOUrl?.split("/").filter(Boolean).pop()?.replaceAll("-"," ")||"Ouverture non renseignée",eco:h.ECO||"—"};}
function timeControl(g){return g.time_control||headers(g.pgn).TimeControl||"";}
function clockSamples(g){
 const tc=timeControl(g);if(!/^\d+(?:\+\d+)?$/.test(tc)||g.time_class==="daily")return [];
 const [base,inc=0]=tc.split("+").map(Number),side=mySide(g);
 const body=(g.pgn||"").replace(/^\[.*\]\s*$/gm,"");
 const tokens=body.match(/\{[^}]*\}|\([^)]*\)|[^\s]+/g)||[];
 let turn=headers(g.pgn).FEN?.split(" ")[1]==="b"?1:0,move=Number(headers(g.pgn).FEN?.split(" ")[5]||1),last=null;
 const previous={white:base,black:base},out=[];
 for(let token of tokens){
 if(token.startsWith("("))continue;
 if(token.startsWith("{")){
 const m=token.match(/\[%clk\s+(\d+):(\d{2}):(\d{2}(?:\.\d+)?)\]/);
 if(m&&last){const remaining=Number(m[1])*3600+Number(m[2])*60+Number(m[3]);const spent=previous[last.side]+inc-remaining;
 if(last.side===side&&spent>=0&&spent<=base+inc)out.push({m:last.move,spent});previous[last.side]=remaining;last=null;}
 continue;
 }
 token=token.replace(/^\d+\.(?:\.\.)?/,"");
 if(!token||/^\$|^(1-0|0-1|1\/2-1\/2|\*|\.\.\.)$/.test(token))continue;
 if(!/^(?:[KQRBN]?[a-h]?[1-8]?x?[a-h][1-8](?:=[QRBN])?|O-O(?:-O)?)[+#?!]*$/.test(token))continue;
 last={side:turn?"black":"white",move};if(turn)move++;turn=1-turn;
 }
 return out;
}
function accuracy(g,side){const v=g.accuracies?.[side];return typeof v==="number"&&Number.isFinite(v)&&v>=0&&v<=100?v:null;}
function activityCells(a){const end=fromISO(prefs.end),cells=[];for(let i=139;i>=0;i--){const d=new Date(end);d.setDate(d.getDate()-i);const key=dateISO(d),n=a.daily[key]||0;cells.push(`<i title="${key} · ${n} parties" style="--level:${Math.min(1,n/8)}"></i>`);}return cells.join("");}
function getFiltered(){
 const start=fromISO(prefs.start),end=fromISO(prefs.end);end.setHours(23,59,59,999);
 return allGames.filter(g=>{
  if(g.rules&&g.rules!=="chess")return false;
  if(![g.white?.username?.toLowerCase(),g.black?.username?.toLowerCase()].includes(username.toLowerCase()))return false;
  const t=new Date((g.end_time||g.start_time||0)*1000);
  return t>=start&&t<=end&&(prefs.mode==="all"||modeOf(g)===prefs.mode);
 }).sort((a,b)=>(a.end_time||0)-(b.end_time||0));
}
function aggregate(games){
 const precision={mine:[],opponent:[]},eloByMode={};let winRun=0,bestWinRun=0;
 let wins=0,losses=0,draws=0,unknown=0;const modes={},timeControls={},opponents={},opens={},oppElo=[],elo=[],hours=Array(24).fill(0),week=Array(7).fill(0),daySet=new Set(),moveBuckets={},ratingDiff=[],duration=[],colors={white:{w:0,l:0,d:0,n:0},black:{w:0,l:0,d:0,n:0}},reasons={},daily={},streaks={best:0,current:0},opponentRatings=[],records={bestWin:null,worstLoss:null,strongest:null,weakest:null},phases={opening:{w:0,l:0,d:0,n:0},middlegame:{w:0,l:0,d:0,n:0},endgame:{w:0,l:0,d:0,n:0}},evalSamples=[];
 for(const g of games){
  const result=outcome(g),mode=modeOf(g),h=headers(g.pgn),op=openingOf(g),side=mySide(g),mine=g[side],opp=g[side==="white"?"black":"white"];
  if(result==="win"){winRun++;bestWinRun=Math.max(bestWinRun,winRun);}else winRun=0;
  const ac=accuracy(g,side),oc=accuracy(g,side==="white"?"black":"white");if(ac!==null&&oc!==null){precision.mine.push(ac);precision.opponent.push(oc);}
  if(result==="win")wins++;else if(result==="loss")losses++;else if(result==="draw")draws++;else unknown++;
  const colorBucket=colors[side];colorBucket.n++;if(result==="win")colorBucket.w++;else if(result==="loss")colorBucket.l++;else if(result==="draw")colorBucket.d++;
  const rawReason=result==="win"?(opp?.result||"win"):result==="loss"?(mine?.result||"loss"):(mine?.result||opp?.result||"draw");
  const reason=({win:"Won",checkmated:"Checkmated",resigned:"Resigned",timeout:"Timeout",abandoned:"Abandoned",stalemate:"Stalemate",repetition:"Repetition",insufficient:"Insufficient material",agreed:"Agreement",timevsinsufficient:"Time vs insufficient material",draw:"Draw"})[rawReason]||rawReason;
  reasons[`${result}:${reason}`]??={result,reason,n:0};reasons[`${result}:${reason}`].n++;
  const moveNumbers=[...(g.pgn||"").replace(/\{[^}]*\}/g,"").matchAll(/\b(\d+)\.(?:\.\.)?/g)].map(m=>Number(m[1]));const plyCount=moveNumbers.length?Math.max(...moveNumbers):0;
  const phase=plyCount<=20?"opening":plyCount<=60?"middlegame":"endgame";
  phases[phase].n++;if(result==="win")phases[phase].w++;else if(result==="loss")phases[phase].l++;else if(result==="draw")phases[phase].d++;
  for(const ev of (g.pgn||"").matchAll(/\[%eval\s+(-?\d+(?:\.\d+)?)(?:,\d+)?\]/g))evalSamples.push(Number(ev[1]));
  modes[mode]??={n:0,w:0,l:0,d:0};modes[mode].n++;if(result!=="unknown")modes[mode][result==="win"?"w":result==="loss"?"l":"d"]++;
  const tcLabel=timeControl(g).replace("+"," | ")||mode;timeControls[tcLabel]??={n:0,w:0,l:0,d:0};timeControls[tcLabel].n++;if(result==="win")timeControls[tcLabel].w++;else if(result==="loss")timeControls[tcLabel].l++;else if(result==="draw")timeControls[tcLabel].d++;
  const opponent=(opp?.username||"Inconnu").toLowerCase();opponents[opponent]??={name:opp?.username||"Inconnu",n:0,w:0,l:0,d:0};opponents[opponent].n++;if(result==="win")opponents[opponent].w++;else if(result==="loss")opponents[opponent].l++;else if(result==="draw")opponents[opponent].d++;
  opens[op.name]??={eco:op.eco,n:0,w:0,l:0,d:0};opens[op.name].n++;if(result==="win")opens[op.name].w++;if(result==="loss")opens[op.name].l++;if(result==="draw")opens[op.name].d++;
  const ts=g.end_time||g.start_time||0;if(ts){const d=new Date(ts*1000),key=dateISO(d);hours[d.getHours()]++;week[d.getDay()]++;daySet.add(key);daily[key]=(daily[key]||0)+1;}
  if(mine?.rating&&ts&&g.rated){const point={t:ts*1000,r:mine.rating};elo.push(point);(eloByMode[mode]??=[]).push(point);}
  if(mine?.rating&&opp?.rating){ratingDiff.push(mine.rating-opp.rating);opponentRatings.push(opp.rating);}
  if(opp?.rating){if(!records.strongest||opp.rating>records.strongest.rating)records.strongest={rating:opp.rating,user:opp.username||"Adversaire",result};if(!records.weakest||opp.rating<records.weakest.rating)records.weakest={rating:opp.rating,user:opp.username||"Adversaire",result};}
  if(result==="win"&&opp?.rating&&(!records.bestWin||opp.rating>records.bestWin.rating))records.bestWin={rating:opp.rating,user:opp.username||"Adversaire",mode};
  if(result==="loss"&&opp?.rating&&(!records.worstLoss||opp.rating<records.worstLoss.rating))records.worstLoss={rating:opp.rating,user:opp.username||"Adversaire",mode};
  for(const sample of clockSamples(g)){moveBuckets[sample.m]??=[];moveBuckets[sample.m].push(sample.spent);}
  const start=g.start_time||Date.parse(`${h.UTCDate?.replaceAll(".","-")}T${h.UTCTime||"00:00:00"}Z`)/1000;
  if(g.time_class!=="daily"&&Number.isFinite(start)&&g.end_time>start)duration.push(g.end_time-start);

 }
 elo.sort((a,b)=>a.t-b.t);
 const openingRows=Object.entries(opens).filter(([,v])=>v.n>=3).sort((a,b)=>b[1].w/Math.max(1,b[1].n)-a[1].w/Math.max(1,a[1].n));
 const moveAvg=Object.entries(moveBuckets).map(([m,a])=>({m:Number(m),avg:a.reduce((x,y)=>x+y,0)/a.length,n:a.length})).sort((a,b)=>a.m-b.m);
 const total=wins+losses+draws+unknown;
 const dayKeys=Object.keys(daily).sort();let bestStreak=0,run=0,prev=null;for(const key of dayKeys){const d=fromISO(key);if(prev&&Math.round((d-prev)/86400000)===1)run++;else run=1;bestStreak=Math.max(bestStreak,run);prev=d;}
 const mostGames=Object.entries(daily).sort((a,b)=>b[1]-a[1])[0]||null;
 const favorite=Object.entries(modes).sort((a,b)=>b[1].n-a[1].n)[0];
 const winPct=total?(wins/total*100):0;
 return {precision,eloByMode,winRun,bestWinRun,games:games.length,wins,losses,draws,unknown,total,winPct,modes,timeControls,opponents,opens,openingRows,elo,hours,week,days:daySet.size,daily,mostGames,bestStreak,moveAvg,duration,ratingDiff,opponentRatings,favorite,colors,reasons,phases,evalSamples,records,avgOpponent:opponentRatings.length?opponentRatings.reduce((x,y)=>x+y,0)/opponentRatings.length:null,avgGame:duration.length?duration.reduce((a,b)=>a+b,0)/duration.length:0};
}
function precisionDelta(a){if(!a.precision.mine.length)return "";const delta=(a.precision.mine.reduce((x,y)=>x+y,0)-a.precision.opponent.reduce((x,y)=>x+y,0))/a.precision.mine.length;return `<b class="precision-delta ${delta>=0?"positive":"negative"}">${delta>=0?"+":"−"}${Math.abs(delta).toFixed(1)} points de % vs adversaires</b>`;}
function rates(v){const n=v.w+v.l+v.d||1;return `V ${(100*v.w/n).toFixed(1)}% · N ${(100*v.d/n).toFixed(1)}% · D ${(100*v.l/n).toFixed(1)}%`;}
function polar(cx,cy,r,a){const rad=(a-90)*Math.PI/180;return [cx+r*Math.cos(rad),cy+r*Math.sin(rad)];}
function arcPath(cx,cy,r1,r2,start,end){if(end-start>=360)end=start+359.9999;const p1=polar(cx,cy,r2,start),p2=polar(cx,cy,r2,end),p3=polar(cx,cy,r1,end),p4=polar(cx,cy,r1,start),large=end-start>180?1:0;return `M ${p1[0]} ${p1[1]} A ${r2} ${r2} 0 ${large} 1 ${p2[0]} ${p2[1]} L ${p3[0]} ${p3[1]} A ${r1} ${r1} 0 ${large} 0 ${p4[0]} ${p4[1]} Z`;}
const chartData=new Map();let chartIndex=0,chartObservers=[];
function donut(a){
 const total=a.wins+a.losses+a.draws;
 if(!total)return `<div class="empty">Aucun résultat connu dans cette sélection.</div>`;
 const labels={win:"Victoire",loss:"Défaite",draw:"Nulle"},translations={Checkmated:"Échec et mat",Resigned:"Abandon",Timeout:"Temps écoulé",Abandoned:"Déconnexion / abandon",Stalemate:"Pat",Repetition:"Répétition","Insufficient material":"Matériel insuffisant",Agreement:"Accord","Time vs insufficient material":"Temps / matériel insuffisant","50move":"Règle des 50 coups",Won:"Victoire",Draw:"Nulle"};
 const hues={win:110,draw:215,loss:2};let angle=0,paths="";
 for(const key of ["win","draw","loss"]){const rows=Object.values(a.reasons).filter(r=>r.result===key).sort((x,y)=>y.n-x.n);
 rows.forEach((r,i)=>{const end=angle+r.n/total*360,detail=`${labels[key]} · ${translations[r.reason]||r.reason} : ${r.n} partie(s) · ${(100*r.n/total).toFixed(1)} % du total · ${(100*r.n/(key==="win"?a.wins:key==="loss"?a.losses:a.draws)).toFixed(1)} % des ${labels[key].toLowerCase()}s`;
 paths+=`<path class="result-segment" tabindex="0" role="img" aria-label="${esc(detail)}" data-detail="${esc(detail)}" d="${arcPath(160,160,78,140,angle,end)}" fill="hsl(${hues[key]} ${key==="draw"?12:48}% ${40+i*5}% )"><title>${esc(detail)}</title></path>`;angle=end;});}
 return `<div class="results-wheel-wrap"><svg class="results-wheel" viewBox="0 0 320 320" aria-label="Répartition des résultats">${paths}<text x="160" y="153" text-anchor="middle" class="wheel-total">${total}</text><text x="160" y="174" text-anchor="middle" class="wheel-caption">PARTIES</text></svg></div><div class="wheel-summary"><span>🟢 ${a.wins} victoires</span><span>⚪ ${a.draws} nulles</span><span>🔴 ${a.losses} défaites</span></div><p class="result-tip" aria-live="polite">Survole un segment pour afficher son détail.</p>${a.unknown?`<p class="note">${a.unknown} résultat(s) inconnu(s), hors roue.</p>`:""}`;
}
function lineChart(points){
 if(!points.length)return `<div class="empty">Aucune partie classée.</div>`;
 const id=String(++chartIndex);chartData.set(id,[...points].sort((a,b)=>a.t-b.t));
 return `<div class="elo-chart" data-chart="${id}"><canvas tabindex="0" role="img" aria-label="Progression Elo : temps en abscisse, Elo en ordonnée. Flèches gauche et droite pour parcourir les parties."></canvas><div class="elo-tip" aria-live="polite">Survole la courbe ou utilise les flèches pour parcourir chaque partie.</div></div>`;
}
function mountElo(chart){
 const p=chartData.get(chart.dataset.chart),canvas=chart.querySelector("canvas"),tip=chart.querySelector(".elo-tip");let selected=-1,frame=0,layout;
 const draw=()=>{frame=0;const w=Math.max(280,chart.clientWidth),h=280,dpr=window.devicePixelRatio||1;canvas.width=w*dpr;canvas.height=h*dpr;canvas.style.height=h+"px";const c=canvas.getContext("2d");c.scale(dpr,dpr);
 const style=getComputedStyle(chart),color=k=>style.getPropertyValue(k).trim(),left=64,right=w-24,top=18,bottom=226;
 let minR=Infinity,maxR=-Infinity;for(const q of p){minR=Math.min(minR,q.r);maxR=Math.max(maxR,q.r);}minR=Math.floor((minR-20)/50)*50;maxR=Math.ceil((maxR+20)/50)*50;
 const minT=p[0].t,maxT=p.at(-1).t,span=maxT-minT||86400000,x=t=>left+(t-minT)/span*(right-left),y=r=>bottom-(r-minR)/(maxR-minR)*(bottom-top);layout={x,y,left,right,minT,span};
 c.font="11px system-ui";c.lineWidth=1;c.textAlign="right";
 for(let i=0;i<=4;i++){const value=minR+(maxR-minR)*i/4,yy=y(value);c.strokeStyle=color("--border");c.beginPath();c.moveTo(left,yy);c.lineTo(right,yy);c.stroke();c.fillStyle=color("--muted");c.fillText(Math.round(value),left-8,yy+4);}
 c.textAlign="center";const ticks=w<450?3:5;
 for(let i=0;i<ticks;i++){const t=minT+(maxT-minT)*i/(ticks-1);c.fillText(new Date(t).toLocaleDateString(undefined,maxT-minT<86400000?{hour:"2-digit",minute:"2-digit"}:{day:"2-digit",month:"short",year:"2-digit"}),left+(right-left)*i/(ticks-1),247);}
 c.fillText("Temps",(left+right)/2,274);c.save();c.translate(14,125);c.rotate(-Math.PI/2);c.fillText("Elo",0,0);c.restore();
 c.strokeStyle=color("--accent");c.lineWidth=1.8;c.lineJoin="round";c.beginPath();p.forEach((q,i)=>{if(i)c.lineTo(x(q.t),y(q.r));else c.moveTo(x(q.t),y(q.r));});c.stroke();
 c.fillStyle=color("--accent");c.beginPath();for(const q of p){c.moveTo(x(q.t)+1.7,y(q.r));c.arc(x(q.t),y(q.r),1.7,0,Math.PI*2);}c.fill();
 if(selected>=0){const q=p[selected];c.beginPath();c.arc(x(q.t),y(q.r),4,0,Math.PI*2);c.fill();tip.textContent=`${new Date(q.t).toLocaleString()} · ${q.r} Elo · partie ${selected+1}/${p.length}`;}
 };
 const schedule=()=>{if(!frame)frame=requestAnimationFrame(draw);};
 canvas.onpointermove=e=>{if(!layout)return;const rect=canvas.getBoundingClientRect(),target=layout.minT+(e.clientX-rect.left-layout.left)/(layout.right-layout.left)*layout.span;let lo=0,hi=p.length-1;while(lo<hi){const mid=(lo+hi)>>1;if(p[mid].t<target)lo=mid+1;else hi=mid;}if(lo&&Math.abs(p[lo-1].t-target)<Math.abs(p[lo].t-target))lo--;if(selected!==lo){selected=lo;schedule();}};
 canvas.onkeydown=e=>{if(!["ArrowLeft","ArrowRight","Home","End"].includes(e.key))return;e.preventDefault();selected=e.key==="Home"?0:e.key==="End"?p.length-1:Math.max(0,Math.min(p.length-1,selected+(e.key==="ArrowLeft"?-1:1)));schedule();};
 const observer=new ResizeObserver(schedule);observer.observe(chart);const themes=new MutationObserver(schedule);themes.observe(document.documentElement,{attributes:true,attributeFilter:["data-chess-stats-theme"]});const media=matchMedia("(prefers-color-scheme: light)");media.addEventListener("change",schedule);chartObservers.push(()=>{observer.disconnect();themes.disconnect();media.removeEventListener("change",schedule);if(frame)cancelAnimationFrame(frame);});draw();
}
function moveChart(rows){
 if(!rows.length)return `<div class="empty">Les archives ne contiennent pas assez d'horodatages par coup pour ce graphique.</div>`;
 const p=rows,maxX=100,maxY=Math.max(1,Math.ceil(Math.max(...p.map(x=>x.avg))*1.15)),x=x=>40+(x/maxX)*710,y=y=>145-(y/maxY)*120;
 const coords=p.map(v=>`${x(v.m)},${y(v.avg)}`).join(" ");
 const dots=p.map(v=>`<circle cx="${x(v.m)}" cy="${y(v.avg)}" r="3" data-move="${v.m}" data-seconds="${v.avg.toFixed(2)}" data-count="${v.n}"/>`).join("");
 return `<div class="move-line-chart"><svg viewBox="0 0 800 185" preserveAspectRatio="none"><line x1="40" y1="145" x2="760" y2="145" class="gridline"/><line x1="40" y1="20" x2="40" y2="145" class="gridline"/><polyline points="${coords}" class="move-line"/>${dots}${Array.from({length:6},(_,i)=>`<text x="${40+i*142}" y="162" text-anchor="middle" class="axis-label">${i*20}</text>`).join("")}${Array.from({length:4},(_,i)=>`<line x1="40" x2="760" y1="${145-i*40}" y2="${145-i*40}" class="gridline"/><text x="34" y="${149-i*40}" text-anchor="end" class="axis-label">${(maxY*i/3).toFixed(1)}</text>`).join("")}<text x="400" y="180" text-anchor="middle" class="axis-title">Numéro du coup</text><text x="12" y="80" transform="rotate(-90 12 80)" text-anchor="middle" class="axis-title">Secondes</text></svg><div class="move-tip">Survole un point pour voir le temps moyen.</div></div>`;
}
function bars(vals,labels){
 const peak=Math.max(1,...vals),step=10**Math.floor(Math.log10(peak)),max=Math.ceil(peak/step)*step;
 const left=76,width=690,base=200,height=170,slot=width/vals.length;
 const grids=Array.from({length:5},(_,i)=>{const v=max*i/4,y=base-height*i/4;return `<line x1="${left}" x2="770" y1="${y}" y2="${y}" class="gridline"/><text x="${left-8}" y="${y+4}" text-anchor="end" class="axis-label">${fmt(v)}</text>`;}).join("");
 return `<div class="activity-chart"><svg viewBox="0 0 800 260" role="img" aria-label="Nombre de parties par ${vals.length===24?"heure":"jour de la semaine"}">${grids}${vals.map((v,i)=>`<rect x="${left+i*slot+slot*.15}" y="${base-v/max*height}" width="${slot*.7}" height="${v/max*height}" rx="2" fill="var(--accent)" tabindex="0" role="img" aria-label="${esc(labels[i])} : ${v} parties"><title>${esc(labels[i])} : ${v} parties</title></rect><text x="${left+(i+.5)*slot}" y="219" text-anchor="middle" class="axis-label">${esc(labels[i])}</text>`).join("")}<text x="420" y="251" text-anchor="middle" class="axis-title">${vals.length===24?"Heure locale":"Jour de la semaine"}</text><text x="16" y="115" transform="rotate(-90 16 115)" text-anchor="middle" class="axis-title">Parties</text></svg></div>`;
}
function table(rows,heads){return `<div class="table-scroll"><table><thead><tr>${heads.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows||`<tr><td colspan="${heads.length}" class="empty">Pas assez de données pour cette période.</td></tr>`}</tbody></table></div>`;}
function buildInsights(a){
 const items=[];
 const colorsArr=Object.entries(a.colors).filter(([,v])=>v.n>=5).sort((x,y)=>x[1].w/x[1].n-y[1].w/y[1].n);
 if(colorsArr.length){const [c,v]=colorsArr[0];items.push(`<article><b>Couleur à travailler : ${c==="white"?"blancs":"noirs"}</b><p>${rates(v)} sur ${v.n} parties.</p></article>`);}
 const phaseArr=Object.entries(a.phases).filter(([,v])=>v.n>=5).sort((x,y)=>x[1].w/x[1].n-y[1].w/y[1].n);
 if(phaseArr.length){const [ph,v]=phaseArr[0];items.push(`<article><b>Longueur de partie à examiner : ${ph==="opening"?"ouverture":ph==="middlegame"?"milieu de jeu":"finale"}</b><p>${rates(v)} sur ${v.n} parties. Classement approximatif par nombre de coups, sans analyse positionnelle.</p></article>`);}
 const open=[...a.openingRows].filter(x=>x[1].n>=5).sort((x,y)=>x[1].w/x[1].n-y[1].w/y[1].n)[0];
 if(open)items.push(`<article><b>Ouverture à revoir : ${esc(open[0])}</b><p>${rates(open[1])} sur ${open[1].n} parties.</p></article>`);
 const mode=[...Object.entries(a.modes)].filter(x=>x[1].n>=5).sort((x,y)=>x[1].w/x[1].n-y[1].w/y[1].n)[0];
 if(mode)items.push(`<article><b>Cadence la plus difficile : ${esc(mode[0])}</b><p>${rates(mode[1])} sur ${mode[1].n} parties.</p></article>`);
 if(a.moveAvg.length){const slow=a.moveAvg.filter(x=>x.n>=5).sort((x,y)=>y.avg-x.avg)[0];if(slow)items.push(`<article><b>Point de vigilance temps : coup ${slow.m}</b><p>${slow.avg.toFixed(1)} secondes en moyenne sur ${slow.n} mesures. Vérifie si ce temps correspond à des positions critiques.</p></article>`);}
 return items.length?items.join(""):`<p class="note">Pas encore assez de données dans cette sélection pour identifier des axes de progression fiables. Élargis la période.</p>`;
}
function brandLogo(){return `<svg viewBox="0 0 128 128" aria-hidden="true"><rect width="128" height="128" rx="28" fill="#222b28"/><path d="M65 96V72h12v24zm18 0V54h12v42zm18 0V33h12v63z" fill="#81b64c"/><circle cx="37" cy="36" r="13" fill="#f2e4be"/><path d="M26 52h22l-6 12 4 17 10 11v7H18v-7l10-11 4-17z" fill="#f2e4be"/></svg>`;}
function ratingPanel(games){
 const groups={};for(const g of games){if(!g.rated||(g.rules&&g.rules!=="chess"))continue;const result=outcome(g);if(result==="unknown")continue;const mode=modeOf(g);(groups[mode]??=[]).push({r:myRating(g),o:oppRating(g),op:g[mySide(g)==="white"?"black":"white"]?.username?.toLowerCase(),ac:accuracy(g,mySide(g)),oc:accuracy(g,mySide(g)==="white"?"black":"white"),t:g.end_time*1000,s:result==="win"?1:result==="draw"?.5:0});}
 const rows=Object.entries(groups).map(([mode,data])=>{const v=ChessRatingModel.reliability(data);if(!v)return "";return `<article class="rating-tile"><h3>${esc(mode.toUpperCase())}</h3><div class="rating-pair"><div><small>Fiabilité du classement</small><strong>${v.score}<em>/100</em></strong><meter min="0" max="100" value="${v.score}">${v.score}</meter></div><div><small>Dernier Elo archivé</small><strong>${v.current}</strong><small>Victoires : ${(100*v.winrate).toFixed(1)} % · nulles : ${(100*v.drawrate).toFixed(1)} % (pondérées)</small></div></div><p>${v.n} parties · ${v.days} jours · ${v.opponents} adversaires · dernière partie : il y a ${v.age} j</p><p>Écart absolu moyen de précision : ${v.gap===null?"indisponible":v.gap.toFixed(1)+" points de %"} · ${v.precisionN} parties comparables (écart Elo ≤ 150)</p><small>Couverture pondérée précision : ${(v.coverage*100).toFixed(1)} %. Sans données, aucun ajustement de précision.</small><details><summary>Composantes du score</summary>${Object.entries(v.factors).map(([k,n])=>`<div class="score-component"><span>${({volume:"Volume récent",activity:"Jours actifs",diversity:"Diversité adverse",freshness:"Fraîcheur",information:"Information des résultats",stability:"Stabilité du classement"})[k]}</span><b>${Math.round(n*100)}/100</b></div>`).join("")}<div class="score-component"><span>Multiplicateur résultats / winrate</span><b>× ${v.resultFactor.toFixed(3)}</b></div><div class="score-component"><span>Multiplicateur précision</span><b>× ${v.precisionFactor.toFixed(3)}</b></div></details></article>`;}).join("");
 return `<section class="dash-card rating-panel"><div class="card-head"><h2>Fiabilité du classement</h2><span class="tag">180 jours · par cadence</span></div><div class="rating-tiles">${rows||'<p class="empty">Pas de parties classées exploitables sur les 180 derniers jours de la sélection.</p>'}</div><details class="rating-method"><summary>Formule et limites</summary><p>Score heuristique sur 100, pas une probabilité ni un score de talent. Par cadence, parties classées standard de la sélection, 180 derniers jours, 400 dernières au maximum. Poids w = exp(−âge/60). M = Σw ; n effectif = M²/Σw².</p><p>B = V^0,30 × A^0,15 × D^0,15 × F^0,15 × I^0,15 × S^0,10. V = 1−exp(−M/50) ; A = min(1, jours actifs/20) ; D = min(1, adversaires effectifs/25) ; F = exp(−jours depuis dernière partie/60) ; S = 1/(1+(écart-type pondéré Elo/150)²).</p><p>Eᵢ = 1/(1+10^((Elo adverseᵢ−Elo joueurᵢ)/400)). Q = (ln(10)/400)² Σwᵢ Eᵢ(1−Eᵢ). I = 1/(1+(1/(100√Q))²). Le nombre effectif d’adversaires est M²/Σ(masse pondérée par adversaire)².</p><p>W = taux pondéré de victoires ; N = taux pondéré de nulles ; E = moyenne pondérée de Eᵢ. x = max(0, |W+N/2−E|−1/√n effectif). R = 0,75+0,25 exp(−x/0,15). Ainsi une winrate élevée contre des joueurs plus faibles n’est pas automatiquement pénalisée. Les petites fluctuations sont tolérées.</p><p>Précision : seules les parties où les deux précisions sont publiées et où |écart Elo| ≤ 150 sont comparées. d = moyenne pondérée de |précision joueur−précision adverse| en points de %. c = poids de ces parties / M ; nₚ = nombre effectif de ces parties ; ρ = c × min(1,nₚ/20). P = 1−0,10ρ d²/(d²+20²). Sans précisions comparables, P = 1.</p><p><b>Fiabilité = arrondi(100 × B × R × P).</b> Résultats : réduction maximale de 25 % ; précision : réduction maximale de 10 %, modulée par la couverture. Un gros écart de précision peut aussi venir du style, d’une partie facile ou d’une erreur adverse ; ce n’est pas une preuve d’Elo erroné. Les parties analysées sont un échantillon potentiellement biaisé.</p><p>Poids et seuils maison, non calibrés empiriquement. Une progression rapide peut réduire la stabilité. Ce score ne mesure ni le talent ni l’intégrité du joueur et n’est pas le Glicko officiel. <a href="https://www.glicko.net/glicko/glicko.pdf" target="_blank" rel="noopener noreferrer">Référence conceptuelle : classement et incertitude, Mark Glickman</a>.</p></details></section>`;
}
const THEMES=[["chesscom","Chess.com"],["dark","Sombre"],["light","Clair"],["midnight","Minuit"],["forest","Forêt"],["ocean","Océan"],["amethyst","Améthyste"],["sunset","Crépuscule"],["paper","Papier"],["system","Automatique"]];
function applyAppearance(){const p=$("#chess-stats-dashboard");if(!p)return;document.documentElement.dataset.chessStatsTheme=prefs.theme;p.dataset.density=prefs.density;p.dataset.motion=prefs.animations?"on":"off";p.style.setProperty("--font-scale",String(prefs.fontSize/100));if(/^#[0-9a-f]{6}$/i.test(prefs.accent))p.style.setProperty("--accent",prefs.accent);else p.style.removeProperty("--accent");p.querySelectorAll(".dash-grid>.dash-card").forEach((card,i)=>{card.dataset.cardId=String(i);card.hidden=prefs.hiddenCards.includes(String(i));});}
function openSettings(){
 if($("#dash-settings"))return;const focus=document.activeElement,dialog=document.createElement("dialog");dialog.id="dash-settings";dialog.innerHTML=`<form method="dialog"><header><h2>Personnaliser le tableau</h2><button value="cancel" aria-label="Fermer">×</button></header><div class="settings-body"><label>Thème<select id="settings-theme">${THEMES.map(([v,l])=>`<option value="${v}" ${prefs.theme===v?"selected":""}>${l}</option>`).join("")}</select></label><label>Couleur d’accent<input id="settings-accent" type="color" value="${/^#[0-9a-f]{6}$/i.test(prefs.accent)?prefs.accent:"#81b64c"}"></label><label><input type="checkbox" id="settings-native" ${!prefs.accent?"checked":""}> Utiliser l’accent du thème</label><label>Densité<select id="settings-density"><option value="comfortable">Confortable</option><option value="compact" ${prefs.density==="compact"?"selected":""}>Compacte</option></select></label><label>Taille du texte<select id="settings-font">${[90,100,110,120].map(n=>`<option ${prefs.fontSize===n?"selected":""}>${n}</option>`).join("")}</select></label><label><input type="checkbox" id="settings-motion" ${prefs.animations?"checked":""}> Animations</label><fieldset><legend>Graphiques et sections visibles</legend>${[...$("#chess-stats-dashboard").querySelectorAll(".dash-grid>.dash-card")].map((c,i)=>`<label><input type="checkbox" data-card="${i}" ${prefs.hiddenCards.includes(String(i))?"":"checked"}> ${esc(c.querySelector("h2")?.textContent||"Section")}</label>`).join("")}</fieldset></div><footer><button type="button" id="settings-reset">Réinitialiser l’apparence</button><button value="cancel">Annuler</button><button value="save">Enregistrer</button></footer></form>`;
 document.body.append(dialog);$("#settings-accent",dialog).oninput=()=>$("#settings-native",dialog).checked=false;
 $("#settings-reset",dialog).onclick=()=>{prefs={...prefs,theme:"chesscom",accent:"",density:"comfortable",fontSize:100,animations:true,hiddenCards:[]};savePrefs();dialog.close();render();};
 dialog.addEventListener("close",()=>{if(dialog.returnValue==="save"){prefs={...prefs,theme:$("#settings-theme",dialog).value,accent:$("#settings-native",dialog).checked?"":$("#settings-accent",dialog).value,density:$("#settings-density",dialog).value,fontSize:Number($("#settings-font",dialog).value),animations:$("#settings-motion",dialog).checked,hiddenCards:[...dialog.querySelectorAll("[data-card]:not(:checked)")].map(x=>x.dataset.card)};savePrefs();render();}dialog.remove();focus?.focus();});dialog.showModal();
}
function render(){
 chartObservers.forEach(stop=>stop());chartObservers=[];chartData.clear();
 const g=getFiltered(),a=aggregate(g),panel=$("#chess-stats-dashboard");if(!panel)return;
 const openRows=a.openingRows.slice(0,6).map(([n,v])=>`<tr><td>${esc(n)}</td><td>${esc(v.eco)}</td><td>${v.n}</td><td>${(v.w/v.n*100).toFixed(1)}%</td></tr>`).join("");
 const badRows=[...a.openingRows].sort((x,y)=>x[1].w/x[1].n-y[1].w/y[1].n).slice(0,6).map(([n,v])=>`<tr><td>${esc(n)}</td><td>${esc(v.eco)}</td><td>${v.n}</td><td>${(v.w/v.n*100).toFixed(1)}%</td></tr>`).join("");
 const modeRows=Object.entries(a.modes).sort((x,y)=>y[1].n-x[1].n).map(([m,v])=>`<tr><td>${esc(m.toUpperCase())}</td><td>${v.n}</td><td>${v.w}</td><td>${v.d}</td><td>${v.l}</td><td>${rates(v)}</td></tr>`).join("");
 const moves=a.moveAvg.filter(x=>x.m<=100);
 const avgDiff=a.ratingDiff.length?a.ratingDiff.reduce((x,y)=>x+y,0)/a.ratingDiff.length:null;
 const activeDays=a.days;
 const measures=a.moveAvg.reduce((n,v)=>n+v.n,0);const avgMove=measures?a.moveAvg.reduce((n,v)=>n+v.avg*v.n,0)/measures:null;
 const rivalRows=Object.values(a.opponents).filter(x=>x.n>=3).sort((x,y)=>y.n-x.n).slice(0,8).map(v=>`<tr><td>${esc(v.name)}</td><td>${v.n}</td><td>${rates(v)}</td></tr>`).join("");
 const tcRows=Object.entries(a.timeControls).sort((x,y)=>y[1].n-x[1].n).slice(0,8).map(([k,v])=>`<tr><td>${esc(k)}</td><td>${v.n}</td><td>${rates(v)}</td></tr>`).join("");
 panel.innerHTML=`
 <div class="dash-top"><div><div class="brand-mark">${brandLogo()}<div class="eyebrow">CHESS STATS · ANALYSE PERSONNELLE</div></div><h1>Statistiques</h1><div class="subline">${esc(username)} · ${fmt(g.length)} parties dans la sélection</div></div>
 <div class="toolbar"><button id="period-open" class="control">▦ ${labelPeriod()}</button><select id="mode-select" class="control"><option value="all">Toutes les cadences</option>${["bullet","blitz","rapid","daily"].map(m=>`<option value="${m}" ${prefs.mode===m?"selected":""}>${m[0].toUpperCase()+m.slice(1)}</option>`).join("")}</select><select id="theme-select" class="control">${THEMES.map(([v,l])=>`<option value="${v}" ${prefs.theme===v?"selected":""}>${l}</option>`).join("")}</select><button id="settings-open" class="control">⚙ Paramètres</button><button id="export-data" class="control">Exporter CSV</button><button id="refresh-data" class="iconbtn" title="Actualiser">↻</button></div></div>
 ${loadWarning?`<p role="status" class="note">${esc(loadWarning)}</p>`:""}<div class="stat-grid">
 <article class="stat"><label>PARTIES</label><strong>${fmt(a.total)}</strong><small>${fmt(a.days)} jours actifs</small></article>
 <article class="stat"><label>TAUX DE VICTOIRE</label><strong>${a.winPct.toFixed(1)}%</strong><small>${a.wins} victoires</small></article>
 <article class="stat"><label>VICTOIRES CONSÉCUTIVES</label><strong>${a.winRun}</strong><small>record : ${a.bestWinRun} dans la sélection</small></article>
 <article class="stat"><label>CADENCE FAVORITE</label><strong>${a.favorite?esc(a.favorite[0].toUpperCase()):"—"}</strong><small>${a.favorite?fmt(a.favorite[1].n)+" parties":"Aucune donnée"}</small></article>
 <article class="stat"><label>ÉCART ELO MOYEN</label><strong>${avgDiff===null?"—":(avgDiff>0?"+":"")+Math.round(avgDiff)}</strong><small>toi − adversaire au début</small></article>
 <article class="stat"><label>DURÉE MOYENNE</label><strong>${a.avgGame?Math.round(a.avgGame/60)+" min":"—"}</strong><small>par partie archivée</small></article>
 </div>
 <section class="dash-card profile-overview"><div class="profile-heading"><div><h2>${esc(username)}</h2><span class="muted">${publicProfile.joined?`Membre depuis le ${new Date(publicProfile.joined*1000).toLocaleDateString()}`:"Profil"} · ${publicProfile.followers??"—"} abonnés</span></div><div class="profile-kpis"><div><b>${a.games?Math.round(a.games/Math.max(1,a.days)*10)/10:0}</b><small>parties / jour actif</small></div><div><b>${a.avgGame?Math.floor(a.avgGame/60)+"m "+Math.round(a.avgGame%60)+"s":"—"}</b><small>durée moyenne</small></div><div><b>${a.avgOpponent?Math.round(a.avgOpponent):"—"}</b><small>Elo moyen adverse</small></div><div><b>${a.duration.length?Math.round(a.duration.reduce((x,y)=>x+y,0)/3600*10)/10+" h":"—"}</b><small>temps total estimé</small></div><div><b>${a.bestStreak}</b><small>jours de jeu consécutifs</small></div></div></div><div class="activity-strip"><b>Activité quotidienne</b><div class="activity-cells">${activityCells(a)}</div><small>${a.days} jours joués · ${a.mostGames?`record quotidien : ${a.mostGames[1]} parties le ${a.mostGames[0]}`:"aucune activité"}</small></div></section>
 ${ratingPanel(g)}<div class="dash-grid">
 <section class="dash-card"><div class="card-head"><h2>Résultats des parties</h2><span class="tag">${a.total} parties</span></div>${donut(a)}</section>
 <section class="dash-card"><div class="card-head"><h2>Progression Elo</h2><span class="tag">${a.elo.length} points</span></div>${Object.entries(a.eloByMode).map(([m,p])=>`<h3>${esc(m)} · ${p.length} parties classées</h3>${lineChart(p)}`).join("")||`<div class="empty">Aucune partie classée.</div>`}</section>
 <section class="dash-card wide"><div class="card-head"><h2>Activité par heure</h2><span class="tag">Heure locale</span></div>${bars(a.hours,Array.from({length:24},(_,i)=>String(i).padStart(2,"0")+"h"))}</section>
 <section class="dash-card"><div class="card-head"><h2>Activité par jour</h2></div>${bars(a.week,["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"])}</section>
 <section class="dash-card"><div class="card-head"><h2>Cadences jouées</h2></div>${table(modeRows,["Mode","Parties","V","N","D","Taux V / N / D"])}</section>
 <section class="dash-card"><div class="card-head"><h2>Meilleures ouvertures</h2><span class="tag">Min. 3 parties</span></div>${table(openRows,["Ouverture","ECO","Parties","Taux V"])}</section>
 <section class="dash-card"><div class="card-head"><h2>Ouvertures à travailler</h2><span class="tag">Min. 3 parties</span></div>${table(badRows,["Ouverture","ECO","Parties","Taux V"])}</section>
 <section class="dash-card wide"><div class="card-head"><h2>Temps moyen par coup</h2><span class="tag">Graphique · secondes</span></div>${moveChart(moves)}</section>
 <section class="dash-card"><div class="card-head"><h2>Résultats selon la couleur</h2></div>${table(["Blancs","Noirs"].map((n,i)=>{const v=a.colors[i===0?"white":"black"];return `<tr><td>${n}</td><td>${v.n}</td><td>${rates(v)}</td></tr>`}).join(""),["Couleur","Parties","V / N / D"])}</section>
 <section class="dash-card"><div class="card-head"><h2>Résultats par longueur de partie</h2></div>${table(["≤ 20 coups","21–60 coups","> 60 coups"].map((n,i)=>{const v=a.phases[["opening","middlegame","endgame"][i]];return `<tr><td>${n}</td><td>${v.n}</td><td>${rates(v)}</td></tr>`}).join(""),["Phase","Parties","V / N / D"])}</section>
 <section class="dash-card wide"><div class="card-head"><h2>Précision moyenne : toi et tes adversaires</h2></div><div class="precision-grid"><div><strong>${a.precision.mine.length?(a.precision.mine.reduce((x,y)=>x+y,0)/a.precision.mine.length).toFixed(1)+" %":"—"}</strong><span>Ta précision moyenne ${precisionDelta(a)}</span></div><div><strong>${a.precision.opponent.length?(a.precision.opponent.reduce((x,y)=>x+y,0)/a.precision.opponent.length).toFixed(1)+" %":"—"}</strong><span>Précision adverse moyenne</span></div></div><p class="note">${a.precision.mine.length} / ${a.games} parties couvertes (${a.games?Math.round(100*a.precision.mine.length/a.games):0} %). Moyennes par partie sur le même échantillon, lorsque les deux précisions sont publiées par Chess.com. Les parties non analysées sont exclues ; cet échantillon peut être biaisé.</p></section>
 <section class="dash-card"><div class="card-head"><h2>Cadences détaillées</h2></div>${table(tcRows,["Contrôle du temps","Parties","V / N / D"])}</section>
 <section class="dash-card"><div class="card-head"><h2>Adversaires fréquents</h2></div>${table(rivalRows,["Adversaire","Parties","V / N / D"])}</section>
 <section class="dash-card"><div class="card-head"><h2>Gestion du temps</h2></div><div class="time-kpi"><b>${avgMove===null?"—":avgMove.toFixed(1)+" s"}</b><span>Temps moyen estimé par coup</span></div><div class="time-kpi"><b>${a.duration.length?Math.round(a.avgGame/60)+" min":"—"}</b><span>Durée moyenne des parties</span></div></section>
 <section class="dash-card"><div class="card-head"><h2>Records & adversaires</h2></div>${table([["Plus forte victoire",a.records.bestWin],["Défaite contre le plus faible Elo",a.records.worstLoss],["Adversaire le mieux classé",a.records.strongest],["Adversaire le moins classé",a.records.weakest]].map(([label,v])=>`<tr><td>${label}</td><td>${v?`${esc(v.user)} · ${v.rating} Elo`:"—"}</td></tr>`).join(""),["Record","Détail"])}</section>
 <section class="dash-card wide"><div class="card-head"><h2>Où progresser ?</h2><span class="tag">Pistes calculées sur la sélection</span></div><div class="insights">${buildInsights(a)}</div></section>
 </div>
 <div class="dash-foot">Les statistiques sont calculées à partir des parties et informations publiques disponibles. Les métriques nécessitant une analyse moteur ou des données d'horloge non présentes sont indiquées comme indisponibles.</div>
 `;
 applyAppearance();
 $("#settings-open").onclick=openSettings;
 $("#mode-select").onchange=e=>{prefs.mode=e.target.value;savePrefs();render();};
 $("#theme-select").onchange=e=>{prefs.theme=e.target.value;savePrefs();applyAppearance();};
 panel.querySelectorAll(".elo-chart").forEach(mountElo);
 panel.querySelectorAll(".result-segment").forEach(segment=>{const show=()=>segment.closest("section").querySelector(".result-tip").textContent=segment.dataset.detail;segment.onpointerenter=show;segment.onfocus=show;});
 panel.querySelectorAll(".move-line-chart").forEach(chart=>{
 const svg=chart.querySelector("svg"),tip=chart.querySelector(".elo-tip,.move-tip"),dots=[...svg.querySelectorAll("circle")];
 const show=pt=>{if(pt)tip.textContent=pt.dataset.rating?`${pt.dataset.date} · ${pt.dataset.rating} Elo`:`Coup ${pt.dataset.move} · ${pt.dataset.seconds} s · ${pt.dataset.count} mesures`;};
 svg.addEventListener("pointermove",e=>{const rect=svg.getBoundingClientRect(),x=(e.clientX-rect.left)/rect.width*svg.viewBox.baseVal.width;show(dots.reduce((best,d)=>!best||Math.abs(+d.getAttribute("cx")-x)<Math.abs(+best.getAttribute("cx")-x)?d:best,null));});
 dots.forEach(d=>{d.setAttribute("tabindex","0");d.setAttribute("role","img");d.setAttribute("aria-label",d.dataset.rating?`${d.dataset.date} : ${d.dataset.rating} Elo`:`Coup ${d.dataset.move} : ${d.dataset.seconds} secondes`);d.onfocus=()=>show(d);});
 });
 $("#export-data").onclick=()=>{
 const rows=[["date","cadence","couleur","resultat","elo","elo_adverse","precision","precision_adverse"],...g.map(x=>[new Date(x.end_time*1000).toISOString(),modeOf(x),mySide(x),outcome(x),myRating(x),oppRating(x),accuracy(x,mySide(x)),accuracy(x,mySide(x)==="white"?"black":"white")])];
 const csv="\ufeff"+rows.map(row=>row.map(v=>'"'+String(v??"").replaceAll('"','""')+'"').join(";")).join("\r\n");
 const url=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"})),link=document.createElement("a");link.href=url;link.download=`chess-stats-${username}.csv`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 };
 $("#period-open").onclick=openPeriod;
 $("#refresh-data").onclick=async()=>{ if(loading)return; $("#refresh-data").disabled=true;$("#refresh-data").textContent="…";try{await loadData(true);render();}catch(e){alert(e.message)}finally{const b=$("#refresh-data");if(b){b.disabled=false;b.textContent="↻";}}};
}
function labelPeriod(){
 if(prefs.range==="all")return "Toute la période";
 if(prefs.range==="7")return "7 derniers jours";
 if(prefs.range==="30")return "30 derniers jours";
 if(prefs.range==="90")return "90 derniers jours";
 if(prefs.range==="year")return "Cette année";
 if(prefs.range==="lastyear")return "Année dernière";
 return `${prefs.start} — ${prefs.end}`;
}
async function savePrefs(){await chrome.storage.local.set({["chessdash_prefs_"+username.toLowerCase()]:prefs});}
function setPreset(p){
 const end=new Date();let start=new Date();
 if(p==="7")start.setDate(end.getDate()-6);
 else if(p==="30")start.setDate(end.getDate()-29);
 else if(p==="90")start.setDate(end.getDate()-89);
 else if(p==="year")start=new Date(end.getFullYear(),0,1);
 else if(p==="lastyear"){start=new Date(end.getFullYear()-1,0,1);end.setTime(new Date(end.getFullYear()-1,11,31,23,59,59).getTime());}
 else if(p==="all"){start=new Date(2007,0,1);}
 prefs.range=p;prefs.start=dateISO(start);prefs.end=dateISO(end);
}
function openPeriod(){
 if($("#period-modal"))return;
 const old={...prefs},focus=document.activeElement,overlay=document.createElement("div");overlay.id="period-modal";
 overlay.innerHTML=`<div class="period-modal" role="dialog" aria-modal="true" aria-label="Choisir la période"><div class="modal-title">Période <button id="period-x" aria-label="Fermer">×</button></div><div class="modal-body"><nav class="presets">${[["all","Tout"],["7","7 jours"],["30","30 jours"],["90","90 jours"],["year","Cette année"],["lastyear","Année dernière"]].map(([v,l])=>`<button data-preset="${v}">${l}</button>`).join("")}</nav><div class="date-fields"><label>Début<input type="date" id="period-start" value="${prefs.start}" required></label><label>Fin<input type="date" id="period-end" value="${prefs.end}" required></label><p id="period-error" role="alert"></p></div></div><div class="modal-actions"><button id="period-cancel">Annuler</button><button id="period-apply" class="apply">Appliquer</button></div></div>`;
 document.body.append(overlay);let chosen=prefs.range;
 const close=()=>{document.removeEventListener("keydown",onKey);overlay.remove();focus?.focus();};
 const onKey=e=>{if(e.key==="Escape")close();if(e.key==="Tab"){const nodes=[...overlay.querySelectorAll("button,input")],first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}};document.addEventListener("keydown",onKey);
 overlay.querySelectorAll("[data-preset]").forEach(b=>b.onclick=()=>{setPreset(b.dataset.preset);chosen=b.dataset.preset;$("#period-start").value=prefs.start;$("#period-end").value=prefs.end;prefs={...old};});
 overlay.querySelectorAll("input").forEach(i=>i.oninput=()=>chosen="custom");
 $("#period-x").onclick=$("#period-cancel").onclick=close;
 $("#period-apply").onclick=()=>{const start=$("#period-start"),end=$("#period-end");if(!start.checkValidity()||!end.checkValidity()||start.value>end.value){$("#period-error").textContent="Choisis deux dates valides, dans l’ordre.";return;}prefs={...prefs,start:start.value,end:end.value,range:chosen};savePrefs();close();render();};
 overlay.onclick=e=>{if(e.target===overlay)close();};$("#period-x").focus();
}
async function init(){
 const stored=await chrome.storage.local.get("chessdash_prefs_"+username.toLowerCase());
 if(stored["chessdash_prefs_"+username.toLowerCase()])prefs={...prefs,...stored["chessdash_prefs_"+username.toLowerCase()]};
 if(prefs.range!=="custom")setPreset(prefs.range);
 const panel=document.createElement("section");panel.id="chess-stats-dashboard";panel.innerHTML='<div id="dash-status">Chargement des statistiques…</div>';
 (document.querySelector("main")||document.querySelector("#content")||document.body).appendChild(panel);
 try{await loadData();render();}catch(e){panel.innerHTML=`<h2>Statistiques</h2><p class="load-error">${esc(e.message)}</p><p>Vérifie que le profil est public et réessaie.</p>`;}
}
if(globalThis.__CHESSDASH_TEST__)globalThis.__CHESSDASH_TEST__({aggregate,clockSamples,getFiltered,accuracy,setGames:g=>allGames=g,lineChart,moveChart,bars,donut,precisionDelta});else init();
})();
